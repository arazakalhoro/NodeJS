var express = require('express');
var router = express.Router();
var User = require('../models/user');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/* Register */
router.get('/register',function(req, res, next ){
  res.render('register',{
    'title':'Register'
  });
});

/* Login */
router.get('/login',function(req, res, next ){
  res.render('login',{
    'title':'Login'
  });
});

router.post('/register',function(req, res, next){
  var name = req.body.name;
  var email = req.body.email;
  var username = req.body.username;
  var password = req.body.password;
  var confirm_password = req.body.confirm_password;

  if( req.files ){
    console.log('Uploading Image...');
    var profileImageData = req.files[0];
    console.log( profileImageData.originalname );
    //File info
    var profileImageOriginalName      = profileImageData.originalname;
    var profileImageName              = profileImageData.filename;
    var profileImageMime              = profileImageData.mimetype;
    var profileImagePath              = profileImageData.path;
    var profileImageSize              = profileImageData.siz;
  }
  else{
    var profileImageName = 'noimage.png';
  }


  // Form Validation
  req.checkBody('name','Name is required').notEmpty();
  req.checkBody('email','Email is required').notEmpty();
  req.checkBody('email','Email not valid').isEmail();
  req.checkBody('username','Username is required').notEmpty();
  req.checkBody('password','Password is required').notEmpty();
  req.checkBody('password','Password not matched').equals(req.body.password);

  var errors = req.validationErrors();

  if( errors ){
      res.render('register',{
        errors:errors,
        name:name,
        email:email,
        username:username,
        password:password,
        confirm_password:confirm_password
      });
  }
  else{
    var newUser = new User({
      name:name,
      email:email,
      username:username,
      password:password,
      profile_image:profileImageName
    });
    console.log(newUser);
    User.createUser(newUser,function(err,user){
      if( err ) throw err;
      console.log(user);
      console.log(newUser);
    });

    req.flash('message','You are registerd and may log in');
    res.location('/');
    res.redirect('/');
  }
});

router.post('/login',function(req, res, next){
  var username = req.body.username;
  var password = req.body.password;

  req.checkBody('username','Username is required').notEmpty();
  req.checkBody('password','Password is required').notEmpty();

  var errors = req.validationErrors();
  if( errors ){
    res.render('login',{
      errors: errors,
      username:username,
      password:password
    });
  }
  else{

  }
});
module.exports = router;
